import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.*;

import javax.swing.*;


public class BookListSwing extends JFrame implements ActionListener {
   JButton btnOk,btnOk2,btnOk3;
   JButton btnOk4, btnReset;
   JTextArea txtResult;
   JPanel pn1,pn2;

   static Connection con;
   Statement stmt;
   ResultSet rs;
   String Driver = "";
   String url = "jdbc:mysql://localhost:3306/madang?&serverTimezone=Asia/Seoul&useSSL=false";
   String userid = "madang";
   String pwd = "madang";

   public BookListSwing() {
      super("18010909 엄준승");
      layInit();
      conDB();
      setVisible(true);
      setBounds(200, 200, 800, 400); //가로위치,세로위치,가로길이,세로길이
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   }

   public void layInit() {
      btnOk = new JButton("select * from book");
      btnOk2 =new JButton("select * from Customer");
      btnOk3 =new JButton("select * from orders");
      btnOk4 = new JButton("입력");
      btnReset = new JButton("초기화");
      
      
      txtResult = new JTextArea();
      txtResult.setEditable(false);
      
      pn1 = new JPanel();
      pn1.add(btnOk);
      pn1.add(btnOk3);
      pn1.add(btnOk2);
      pn1.add(btnReset); // 초기화 
      pn1.add(btnOk4);
     
      JScrollPane scrollPane = new JScrollPane(txtResult);
      
      add("North", pn1);
      add("Center", scrollPane);
      
      btnOk.addActionListener(this);
      btnReset.addActionListener(this);
      btnOk2.addActionListener(this);//Customer
      btnOk3.addActionListener(this);//orders
      btnOk4.addActionListener(this);
   }

   public void conDB() {
      try {
         Class.forName("com.mysql.cj.jdbc.Driver");
         System.out.println("드라이버 로드 성공");
      } catch (ClassNotFoundException e) {
         e.printStackTrace();
      }
      try { /* 데이터베이스를 연결하는 과정 */
          System.out.println("데이터베이스 연결 준비...");
          con = DriverManager.getConnection(url, userid, pwd);
          System.out.println("데이터베이스 연결 성공");
       } catch (SQLException e1) {
          e1.printStackTrace();
       }
   }

   @Override
   public void actionPerformed(ActionEvent e) {
      
      try {
         stmt = con.createStatement();
         String query = "SELECT * FROM Book ";
         String query1 = "SELECT * FROM Customer ";//Customer b2
         String query2 = "SELECT * FROM Orders ";//orders b3
         String dq1 = "DELETE FROM  Orders";
         String dq2 = "DELETE FROM  Book";
         String dq3 = "DELETE FROM  Customer";	
         
        
         String bq1 = "INSERT INTO Book VALUES(1, '축구의 역사', '굿스포츠', 7000)"; 
         String bq2 = "INSERT INTO Book VALUES(2, '축구아는 여자', '나무수', 13000)";
         String bq3 = "INSERT INTO Book VALUES(3, '축구의 이해', '대한미디어', 22000)";
         String bq4 =  "INSERT INTO Book VALUES(4, '골프 바이블', '대한미디어', 35000)";
         String bq5 = "INSERT INTO Book VALUES(5, '피겨 교본', '굿스포츠', 8000)";
         String bq6 =  "INSERT INTO Book VALUES(6, '역도 단계별기술', '굿스포츠', 6000)";
         String bq7 = "INSERT INTO Book VALUES(7, '야구의 추억', '이상미디어', 20000)";
         String bq8 =  "INSERT INTO Book VALUES(8, '야구를 부탁해', '이상미디어', 13000)";
         String bq9 = "INSERT INTO Book VALUES(9, '올림픽 이야기', '삼성당', 7500)";
         String bq10 = "INSERT INTO Book VALUES(10, 'Olympic Champions', 'Pearson', 13000)";
         String bq11 = "INSERT INTO Book VALUES(11, '슬램덩크1', '아사히', 3500)";
         String bq12 = "INSERT INTO Book VALUES(12, '슬램덩크2', '아사히', 3500)";
         String bq13 = "INSERT INTO Book VALUES(13, '슬램덩크3', '아사히', 3500)";
         String bq14 = "INSERT INTO Book VALUES(14, '슬램덩크4', '아사히', 3500)";
         String bq15 = "INSERT INTO Book VALUES(15, '슬램덩크5', '아사히', 3500)";
         String bq16 = "INSERT INTO Book VALUES(16, '슬램덩크6', '아사히', 3500)";
         String bq17 = "INSERT INTO Book VALUES(17, '슬램덩크7', '아사히', 3500)";
         String bq18 = "INSERT INTO Book VALUES(18, '슬램덩크8', '아사히', 3500)";
         String bq19 = "INSERT INTO Book VALUES(19, '슬램덩크9', '아사히', 3500)";
         String bq20 = "INSERT INTO Book VALUES(20, '슬램덩크10', '아사히', 3500)";
         
         String cq1 = "INSERT INTO Customer VALUES (1, '박지성', '영국 맨체스타', '000-5000-0001')";
         String cq2 = "INSERT INTO Customer VALUES (2, '김연아', '대한민국 서울', '000-6000-0001')";  
         String cq3 = "INSERT INTO Customer VALUES (3, '장미란', '대한민국 강원도', '000-7000-0001')";
         String cq4 = "INSERT INTO Customer VALUES (4, '추신수', '미국 클리블랜드', '000-8000-0001')";
         String cq5 = "INSERT INTO Customer VALUES (5, '박세리', '대한민국 서울',  NULL)";
         String cq6 = "INSERT INTO Customer VALUES (6, '박기연', '대한믹국 군포',  '010-0000-1230')";
         String cq7 = "INSERT INTO Customer VALUES (7, '김원중', '대한민국 대전',  '010-0000-1230')";
         String cq8 = "INSERT INTO Customer VALUES (8, '정준호', '대한민국 경주',  '010-0000-1230')";
         String cq9 = "INSERT INTO Customer VALUES (9, '김유미', '대한민국 진주',  '010-0000-1230')";
         String cq10 ="INSERT INTO Customer VALUES (10, '문재인', '대한민국 부산',  '010-0000-1230')";
         
         String oq1="INSERT INTO Orders VALUES (1, 1, 1, 6000, STR_TO_DATE('2014-07-01','%Y-%m-%d'))"; 
         String oq2="INSERT INTO Orders VALUES (2, 1, 3, 21000, STR_TO_DATE('2014-07-03','%Y-%m-%d'))";
         String oq3="INSERT INTO Orders VALUES (3, 2, 5, 8000, STR_TO_DATE('2014-07-03','%Y-%m-%d'))"; 
         String oq4= "INSERT INTO Orders VALUES (4, 3, 6, 6000, STR_TO_DATE('2014-07-04','%Y-%m-%d'))"; 
         String oq5="INSERT INTO Orders VALUES (5, 4, 7, 20000, STR_TO_DATE('2014-07-05','%Y-%m-%d'))";
         String oq6= "INSERT INTO Orders VALUES (6, 1, 2, 12000, STR_TO_DATE('2014-07-07','%Y-%m-%d'))";
         String oq7="INSERT INTO Orders VALUES (7, 4, 8, 13000, STR_TO_DATE( '2014-07-07','%Y-%m-%d'))";
         String oq8= "INSERT INTO Orders VALUES (8, 3, 10, 12000, STR_TO_DATE('2014-07-08','%Y-%m-%d'))"; 
         String oq9= "INSERT INTO Orders VALUES (9, 2, 10, 7000, STR_TO_DATE('2014-07-09','%Y-%m-%d'))"; 
         String oq10= "INSERT INTO Orders VALUES (10, 3, 8, 13000, STR_TO_DATE('2014-07-11','%Y-%m-%d'))";
         String oq11= "INSERT INTO Orders VALUES (11, 3, 8, 13000, STR_TO_DATE('2014-07-11','%Y-%m-%d'))";
         String oq12= "INSERT INTO Orders VALUES (12, 3, 8, 13000, STR_TO_DATE('2014-07-11','%Y-%m-%d'))";
         String oq13= "INSERT INTO Orders VALUES (13, 3, 8, 13000, STR_TO_DATE('2014-07-12','%Y-%m-%d'))";
         String oq14= "INSERT INTO Orders VALUES (14, 3, 8, 13000, STR_TO_DATE('2014-07-12','%Y-%m-%d'))";
         String oq15= "INSERT INTO Orders VALUES (15, 3, 8, 13000, STR_TO_DATE('2014-07-12','%Y-%m-%d'))";
         String oq16= "INSERT INTO Orders VALUES (16, 3, 8, 13000, STR_TO_DATE('2014-07-13','%Y-%m-%d'))";
         String oq17= "INSERT INTO Orders VALUES (17, 3, 8, 13000, STR_TO_DATE('2014-07-13','%Y-%m-%d'))";
         String oq18= "INSERT INTO Orders VALUES (18, 3, 8, 13000, STR_TO_DATE('2014-07-13','%Y-%m-%d'))";
         String oq19= "INSERT INTO Orders VALUES (19, 3, 8, 13000, STR_TO_DATE('2014-07-14','%Y-%m-%d'))";
         String oq20= "INSERT INTO Orders VALUES (20, 3, 8, 13000, STR_TO_DATE('2014-07-14','%Y-%m-%d'))";
         
         
         
         
         
         if (e.getSource() == btnOk2) 
         {
            txtResult.setText("");
            txtResult.setText("CUSTID               NAME               ADDRESS               PHONE\n");
            rs = stmt.executeQuery(query1);
            while (rs.next()) {
               String str = rs.getInt(1) + "\t" + rs.getString(2) + "\t" + rs.getString(3) + "\t" + rs.getString(4)
                     + "\n";
               txtResult.append(str);
            }
         } 
         
         if (e.getSource() == btnOk3) 
         {
            txtResult.setText("");
            txtResult.setText("orderid               custid               bookid               saleprice               orderdate\n");
            rs = stmt.executeQuery(query2);
            while (rs.next()) {
               String str = rs.getInt(1) + "\t" + rs.getInt(2) + "\t" + rs.getInt(3) + "\t" + rs.getInt(4)+ "\t" + rs.getString(5)
                     + "\n";
               txtResult.append(str);
            }
         } 
         
         if (e.getSource() == btnOk) 
         {
            txtResult.setText("");
            txtResult.setText("BOOKNO               BOOK NAME                              PUBLISHER        PRICE\n");
            rs = stmt.executeQuery(query);
            while (rs.next()) {
               String str = rs.getInt(1) + "\t   " +rs.getString(2) + "\t\t" + rs.getString(3) + "\t" + rs.getInt(4)
                     + "\n";
               txtResult.append(str);
            }
         } 
         if (e.getSource() == btnReset) {
            txtResult.setText("");
           
            stmt.executeUpdate(dq1);
            stmt.executeUpdate(dq2);
            stmt.executeUpdate(dq3);
            
            stmt.executeUpdate(cq1);
            stmt.executeUpdate(cq2);
            stmt.executeUpdate(cq3);
            stmt.executeUpdate(cq4);
            stmt.executeUpdate(cq5);
            stmt.executeUpdate(cq6);
            stmt.executeUpdate(cq7);
            stmt.executeUpdate(cq8);
            stmt.executeUpdate(cq9);
            stmt.executeUpdate(cq10);
            
            stmt.executeUpdate(bq1);
            stmt.executeUpdate(bq2);
            stmt.executeUpdate(bq3);
            stmt.executeUpdate(bq4);
            stmt.executeUpdate(bq5);
            stmt.executeUpdate(bq6);
            stmt.executeUpdate(bq7);
            stmt.executeUpdate(bq8);
            stmt.executeUpdate(bq9);
            stmt.executeUpdate(bq10);
            stmt.executeUpdate(bq11);
            stmt.executeUpdate(bq12);
            stmt.executeUpdate(bq13);
            stmt.executeUpdate(bq14);
            stmt.executeUpdate(bq15);
            stmt.executeUpdate(bq16);
            stmt.executeUpdate(bq17);
            stmt.executeUpdate(bq18);
            stmt.executeUpdate(bq19);
            stmt.executeUpdate(bq20);
            
            stmt.executeUpdate(oq1);
            stmt.executeUpdate(oq2);
            stmt.executeUpdate(oq3);
            stmt.executeUpdate(oq4);
            stmt.executeUpdate(oq5);
            stmt.executeUpdate(oq6);
            stmt.executeUpdate(oq7);
            stmt.executeUpdate(oq8);
            stmt.executeUpdate(oq9);
            stmt.executeUpdate(oq10);
            stmt.executeUpdate(oq11);
            stmt.executeUpdate(oq12);
            stmt.executeUpdate(oq13);
            stmt.executeUpdate(oq14);
            stmt.executeUpdate(oq15);
            stmt.executeUpdate(oq16);
            stmt.executeUpdate(oq17);
            stmt.executeUpdate(oq18);
            stmt.executeUpdate(oq19);
            stmt.executeUpdate(oq20);

         }
         if(e.getSource() == btnOk4) {
            switch(JOptionPane.showInputDialog("Book/Customer/Orders 중 하나 입력").toLowerCase()) {
               case "book":

                  //String bq20 = "INSERT INTO Book VALUES(20, '슬램덩크10', '아사히', 3500)";

                  try {
                     int bookno = Integer.parseInt(JOptionPane.showInputDialog("책 넘버"));
                     String bookname = JOptionPane.showInputDialog("책 이름");
                     String publisher = JOptionPane.showInputDialog("출판사");
                     int price = Integer.parseInt(JOptionPane.showInputDialog("가격"));

                     stmt.executeUpdate("INSERT INTO Book VALUES(" + bookno + ", '" + bookname + "', '" + publisher + "', " + price + ")");
                  } catch(Exception ex) {
                     JOptionPane.showMessageDialog(this, ex.getMessage());
                     ex.printStackTrace();
                  }
                  break;
               case "orders":

                  //String cq10 ="INSERT INTO Customer VALUES (10, '문재인', '대한민국 부산',  '010-0000-1230')";

                  try {
                     int bookno = Integer.parseInt(JOptionPane.showInputDialog("orderId"));
                     int bookname = Integer.parseInt(JOptionPane.showInputDialog("custId"));
                     int publisher = Integer.parseInt(JOptionPane.showInputDialog("bookId"));
                     int price = Integer.parseInt(JOptionPane.showInputDialog("saleprice"));
                     String orderDate = JOptionPane.showInputDialog("orderdate");

                     String sql = "INSERT INTO Orders VALUES(" + bookno + ", " + bookname + ", " + publisher + ", " + price + ", STR_TO_DATE('" + orderDate + "', '%Y-%m-%d'))";
                     System.out.println(sql);

                     stmt.executeUpdate("INSERT INTO Orders VALUES(" + bookno + ", " + bookname + ", " + publisher + ", " + price + ", STR_TO_DATE('" + orderDate + "', '%Y-%m-%d'))");
                  } catch(Exception ex) {
                     JOptionPane.showMessageDialog(this, ex.getMessage());
                     ex.printStackTrace();
                  }
                  break;
               //String oq20= "INSERT INTO Orders VALUES (20, 3, 8, 13000, STR_TO_DATE('2014-07-14','%Y-%m-%d'))";
               case "customer":

                  //String cq10 ="INSERT INTO Customer VALUES (10, '문재인', '대한민국 부산',  '010-0000-1230')";

                  try {
                     int bookno = Integer.parseInt(JOptionPane.showInputDialog("ID"));
                     String bookname = JOptionPane.showInputDialog("이름");
                     String publisher = JOptionPane.showInputDialog("주소");
                     String price = JOptionPane.showInputDialog("휴대폰 번호");

                     stmt.executeUpdate("INSERT INTO Customer VALUES(" + bookno + ", '" + bookname + "', '" + publisher + "', '" + price + "')");
                  } catch(Exception ex) {
                     JOptionPane.showMessageDialog(this, ex.getMessage());
                     ex.printStackTrace();
                  }
                  break;
               default:
                  JOptionPane.showMessageDialog(this, "셋중 하나를 입력해주세요");
                  break;
            }

         }
      } catch (Exception e2) {
         System.out.println("쿼리 읽기 실패 :" + e2);
         /* } 
       finally {
         try {
            if (rs != null)
               rs.close();
            if (stmt != null)
               stmt.close();
            if (con != null)
               con.close();
         } catch (Exception e3) {
            // TODO: handle exception
         }*/
      }
   }

   public static void main(String[] args) {
	   BookListSwing BLS = new BookListSwing();
	   
	   BLS.addWindowListener(new WindowAdapter() {
		   public void windowClosing(WindowEvent we) {
			   try {
				   con.close();
			   }catch(Exception e4){}
			   System.exit(0);
		   }
	});
   }
}


